package br.com.bruna.mentoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
